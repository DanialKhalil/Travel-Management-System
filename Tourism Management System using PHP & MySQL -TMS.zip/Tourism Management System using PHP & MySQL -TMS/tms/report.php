<?php
session_start();
include('includes/config.php');

if (isset($_POST['generateReport'])) {
    // Get data from the submitted form (adjust field names accordingly)
    $pid = intval($_GET['pkgid']);
    $useremail = $_SESSION['login'];
    $fromdate = $_POST['fromdate'];
    $todate = $_POST['todate'];
    $comment = $_POST['comment'];

    // Add your report generation logic here
    // You can use the collected data to create a PDF, Excel, or any other type of report
    // For simplicity, let's just echo the collected data in this example
    echo "Package ID: $pid<br>";
    echo "User Email: $useremail<br>";
    echo "From Date: $fromdate<br>";
    echo "To Date: $todate<br>";
    echo "Comment: $comment<br>";
}
?>
